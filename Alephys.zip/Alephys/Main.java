import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TransactionService transactionService = new TransactionServiceImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Expense Tracker ===");
            System.out.println("1. Add Transaction");
            System.out.println("2. Load Transactions from File");
            System.out.println("3. Save Transactions to File");
            System.out.println("4. View Monthly Summary");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    transactionService.addTransaction();
                    break;
                case "2":
                    System.out.print("Enter filename: ");
                    transactionService.loadTransactions(scanner.nextLine().trim());
                    break;
                case "3":
                    System.out.print("Enter filename: ");
                    transactionService.saveTransactions(scanner.nextLine().trim());
                    break;
                case "4":
                    transactionService.viewMonthlySummary();
                    break;
                case "5":
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
