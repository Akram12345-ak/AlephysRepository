public interface TransactionService {
    void addTransaction();
    void loadTransactions(String fileName);
    void saveTransactions(String fileName);
    void viewMonthlySummary();
}
