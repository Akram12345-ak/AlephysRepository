import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

public class TransactionServiceImpl implements TransactionService {
    private final List<Transaction> transactions = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    @Override
    public void addTransaction() {
        System.out.print("Enter type (income/expense): ");
        String typeStr = scanner.nextLine().trim().toLowerCase();
        Transaction.Type type = typeStr.equals("income") ? Transaction.Type.INCOME : Transaction.Type.EXPENSE;

        System.out.print("Enter date (YYYY-MM-DD): ");
        LocalDate date = LocalDate.parse(scanner.nextLine());

        System.out.print("Enter category (e.g., salary/food/rent/travel): ");
        String category = scanner.nextLine().trim();

        System.out.print("Enter amount: ");
        double amount = Double.parseDouble(scanner.nextLine());

        System.out.print("Enter description: ");
        String description = scanner.nextLine().trim();

        transactions.add(new Transaction(type, date, category, amount, description));
        System.out.println("Transaction added.");
    }

    @Override
    public void loadTransactions(String fileName) {
        try (Scanner fileScanner = new Scanner(new File(fileName))) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                Transaction t = Transaction.fromString(line);
                transactions.add(t);
            }
            System.out.println("Transactions loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }

    @Override
    public void saveTransactions(String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (Transaction t : transactions) {
                writer.write(t.toString() + "\n");
            }
            System.out.println("Transactions saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    @Override
    public void viewMonthlySummary() {
        Map<String, Double> incomeMap = new HashMap<>();
        Map<String, Double> expenseMap = new HashMap<>();
        double totalIncome = 0, totalExpense = 0;

        for (Transaction t : transactions) {
            String monthKey = t.getDate().getMonth() + " " + t.getDate().getYear();

            if (t.getType() == Transaction.Type.INCOME) {
                incomeMap.put(monthKey, incomeMap.getOrDefault(monthKey, 0.0) + t.getAmount());
                totalIncome += t.getAmount();
            } else {
                expenseMap.put(monthKey, expenseMap.getOrDefault(monthKey, 0.0) + t.getAmount());
                totalExpense += t.getAmount();
            }
        }

        System.out.println("---- Monthly Summary ----");
        Set<String> months = new HashSet<>();
        months.addAll(incomeMap.keySet());
        months.addAll(expenseMap.keySet());

        for (String month : months) {
            double income = incomeMap.getOrDefault(month, 0.0);
            double expense = expenseMap.getOrDefault(month, 0.0);
            System.out.printf("%s -> Income: %.2f, Expense: %.2f, Net: %.2f%n",
                    month, income, expense, income - expense);
        }

        System.out.printf("Total Income: %.2f | Total Expense: %.2f | Net Savings: %.2f%n",
                totalIncome, totalExpense, totalIncome - totalExpense);
    }
}
